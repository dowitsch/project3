<form name="login" action="<?php echo getValue('phpmodule'); ?>" method="post">
</form>
