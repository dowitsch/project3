<form name="registration" action="<?php echo getValue('phpmodule'); ?>" method="post">
</form>
